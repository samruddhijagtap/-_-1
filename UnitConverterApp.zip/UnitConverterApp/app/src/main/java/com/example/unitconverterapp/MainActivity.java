package com.example.unitconverterapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView t1, res;
    CheckBox cf, ck, fc, fk, kc, kf;
    EditText ed1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = findViewById(R.id.t1);
        res = findViewById(R.id.res);
        cf = findViewById(R.id.cf);
        ck = findViewById(R.id.ck);
        fc = findViewById(R.id.fc);
        fk = findViewById(R.id.fk);
        kc = findViewById(R.id.kc);
        kf = findViewById(R.id.kf);
        ed1 = findViewById(R.id.ed1);
        b1 = findViewById(R.id.b1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ed = ed1.getText().toString().trim();
                if (ed.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter Temperature", Toast.LENGTH_SHORT).show();
                    return;
                }

                double temp = Double.parseDouble(ed);
                StringBuilder result = new StringBuilder();

                if (cf.isChecked()) {
                    double fahrenheit = (temp * 9 / 5) + 32;
                    result.append("Celsius to Fahrenheit: ").append(fahrenheit).append("\n");
                }
                if (ck.isChecked()) {
                    double kelvin = temp + 273.15;
                    result.append("Celsius to Kelvin: ").append(kelvin).append("\n");
                }
                if (fc.isChecked()) {
                    double celsius = (temp - 32) * 5 / 9;
                    result.append("Fahrenheit to Celsius: ").append(celsius).append("\n");
                }
                if (fk.isChecked()) {
                    double kelvin = (temp - 32) * 5 / 9 + 273.15;
                    result.append("Fahrenheit to Kelvin: ").append(kelvin).append("\n");
                }
                if (kc.isChecked()) {
                    double celsius = temp - 273.15;
                    result.append("Kelvin to Celsius: ").append(celsius).append("\n");
                }
                if (kf.isChecked()) {
                    double fahrenheit = (temp - 273.15) * 9 / 5 + 32;
                    result.append("Kelvin to Fahrenheit: ").append(fahrenheit).append("\n");
                }

                if (result.length() == 0) {
                    result.append("Please select at least one conversion.");
                }

                res.setText(result.toString());
            }
        });
    }
}